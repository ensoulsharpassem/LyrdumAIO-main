 [![N|Solid](https://ensoulsharp.com/uploads/a7a666e463350db53ec74d083af79da0.png)](https://nodesource.com/products/nsolid) 
# LyrdumAIO 
# [Discord server](https://discord.com/invite/KfQFVhdqtz)

### Install Link

```sh
https://github.com/Lyrdum/LyrdumAIO
```


### Supported Champions
| Plugin | Status | Last Update |
| ------ | ------ | ------ |
| Lux | Updated | 05-29-2021 |
| Cassiopeia | Updated | 05-29-2021 |
| Thresh | Updated | 05-29-2021 |
| Karthus | Updated | 05-29-2021 |
| Brand | Updated | 05-29-2021 |




            

###  BUG FIX         

      > Cassiopea R not casting well [Fixed]
      > Karthus lasthit on dead minion [Fixed]
      > Thresh lantern [Fixed]

### NEW FEATURES
     > Farming logic improved

### NEXT VERSION FEATURES
    > More Advanced farm logic
    
    
### Each Champion has Specific keys be sure to check them in [LyrdumAIO] Menu


[//]: # (These are reference links used in the body of this note and get stripped out when the markdown processor does its job. There is no need to format nicely because it shouldn't be seen. Thanks SO - http://stackoverflow.com/questions/4823468/store-comments-in-markdown-syntax)


   [dill]: <https://github.com/joemccann/dillinger>
   [git-repo-url]: <https://github.com/joemccann/dillinger.git>
   [john gruber]: <http://daringfireball.net>
   [df1]: <http://daringfireball.net/projects/markdown/>
   [markdown-it]: <https://github.com/markdown-it/markdown-it>
   [Ace Editor]: <http://ace.ajax.org>
   [node.js]: <http://nodejs.org>
   [Twitter Bootstrap]: <http://twitter.github.com/bootstrap/>
   [jQuery]: <http://jquery.com>
   [@tjholowaychuk]: <http://twitter.com/tjholowaychuk>
   [express]: <http://expressjs.com>
   [AngularJS]: <http://angularjs.org>
   [Gulp]: <http://gulpjs.com>

   [PlDb]: <https://github.com/joemccann/dillinger/tree/master/plugins/dropbox/README.md>
   [PlGh]: <https://github.com/joemccann/dillinger/tree/master/plugins/github/README.md>
   [PlGd]: <https://github.com/joemccann/dillinger/tree/master/plugins/googledrive/README.md>
   [PlOd]: <https://github.com/joemccann/dillinger/tree/master/plugins/onedrive/README.md>
   [PlMe]: <https://github.com/joemccann/dillinger/tree/master/plugins/medium/README.md>
   [PlGa]: <https://github.com/RahulHP/dillinger/blob/master/plugins/googleanalytics/README.md>
